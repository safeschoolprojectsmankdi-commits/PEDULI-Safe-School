// Isi dengan Project URL dan publishable/anon key Supabase milik proyekmu.
// Jangan pernah memasukkan service_role key ke aplikasi Android atau file frontend.
window.PEDULI_CONFIG = {
  url: "GANTI_DENGAN_SUPABASE_PROJECT_URL",
  anonKey: "GANTI_DENGAN_SUPABASE_PUBLISHABLE_ATAU_ANON_KEY"
};
