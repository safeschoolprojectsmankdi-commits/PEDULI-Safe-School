plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "id.sman4kendari.peduli"
    compileSdk = 35
    defaultConfig {
        applicationId = "id.sman4kendari.peduli"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
    }
}
