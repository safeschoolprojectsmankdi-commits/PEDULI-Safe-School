# PEDULI Safe School — Android starter project

Ini adalah **starter project Android Studio**, bukan APK yang sudah dibangun. Aplikasi memakai Android WebView yang memuat antarmuka lokal dari `app/src/main/assets/index.html`. Fitur formulir, tracking, dan dashboard sudah ditulis untuk berkomunikasi dengan Supabase melalui `supabase-js`.

## Yang tersedia
- Aplikasi Android dengan identitas PEDULI hijau zamrud dan putih.
- Form pelaporan, kategori kejadian, pilihan anonim, kode pelacakan.
- Pelacakan status melalui fungsi database `peduli_track_report`.
- Login petugas melalui Supabase Auth.
- Dashboard petugas, statistik status, daftar laporan, pembaruan status dan catatan.
- SQL awal dan RLS di `supabase_setup.sql`.

## Langkah 1 — Siapkan Supabase
1. Buka proyek Supabase yang akan digunakan.
2. Buka **SQL Editor** dan tinjau/jalankan `supabase_setup.sql`.
3. Buka Project Settings / API (label menu bisa berubah). Salin Project URL dan **publishable key** atau anon key lama.
4. Buka `app/src/main/assets/config.js`, isi `url` dan `anonKey`.
5. Jangan pernah memasukkan `service_role` key ke aplikasi, HTML, atau chat.

> Jika proyekmu sudah mempunyai tabel `reports` dan `staff_users`, jangan langsung jalankan skema ini tanpa memeriksa perbedaannya. Skrip ini membuat tabel baru `peduli_reports` dan `peduli_staff` supaya tidak mengubah tabel yang sudah ada.

## Langkah 2 — Buat akun petugas
1. Di Supabase Authentication, buat akun email petugas yang disetujui sekolah.
2. Dapatkan UUID pengguna tersebut.
3. Jalankan SQL berikut dengan UUID yang benar di SQL Editor:
   `insert into public.peduli_staff(user_id, display_name) values ('UUID_PETUGAS', 'Petugas Safe School');`
4. Jangan membuat akun petugas umum atau membagikan akun bersama.

## Langkah 3 — Bangun APK
1. Pindahkan folder `PeduliAndroid` ke komputer yang memiliki Android Studio.
2. Buka folder itu dari Android Studio, lalu tunggu Gradle Sync selesai.
3. Pilih **Build > Build APK(s)**.
4. APK debug biasanya berada di `app/build/outputs/apk/debug/app-debug.apk`.
5. Uji pada perangkat khusus uji coba sebelum dipakai siswa.

## Catatan penting sebelum penggunaan nyata
- Belum ada APK yang dibangun/ditandatangani dalam paket ini.
- Supabase harus dikonfigurasi dan diuji sebelum fitur online bekerja.
- Aplikasi ini prototipe teknis, belum melalui audit keamanan atau persetujuan sekolah.
- RLS membatasi pembacaan/pembaruan ke pengguna di `peduli_staff`, namun endpoint pelaporan publik tetap bisa disalahgunakan. Sebelum peluncuran nyata, tambahkan rate limiting/anti-spam (misalnya Edge Function), rencana retensi data, mekanisme penanganan insiden, dan prosedur akses terbatas.
- Tracking hanya menampilkan kode, kategori, status, dan tanggal. Kode harus acak dan dirahasiakan.
- Android WebView menggunakan CDN untuk `supabase-js`, sehingga koneksi internet diperlukan untuk fitur Supabase.
